package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import net.minecraft.class_2338;
import net.minecraft.class_852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_852.class)
public abstract class ChunkOcclusionDataBuilderMixin {
    @Inject(method = "markClosed", at = @At("HEAD"), cancellable = true)
    private void zeroHack$xrayMarkClosed(class_2338 pos, CallbackInfo ci) {
        if (XRay.isActive()) ci.cancel();
    }
}
