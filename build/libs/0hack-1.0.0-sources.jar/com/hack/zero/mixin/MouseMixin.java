package com.hack.zero.mixin;

import com.hack.zero.ZeroHack;
import com.hack.zero.module.render.Freecam;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseMixin {

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void zeroHack$onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (class_310.method_1551().field_1755 != null) return;

        ZeroHack instance = ZeroHack.getInstance();
        if (instance == null) return;

        Freecam freecam = (Freecam) instance.getModuleManager().getModule("Freecam").orElse(null);
        if (freecam != null && freecam.isEnabled() && freecam.onScroll(vertical)) {
            ci.cancel();
        }
    }
}
