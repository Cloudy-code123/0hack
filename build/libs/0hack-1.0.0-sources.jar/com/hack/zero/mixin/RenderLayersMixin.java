package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import net.minecraft.class_11515;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_4696;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4696.class)
public abstract class RenderLayersMixin {
    @Inject(method = "getBlockLayer", at = @At("HEAD"), cancellable = true)
    private static void zeroHack$xrayGetBlockLayer(class_2680 state, CallbackInfoReturnable<class_11515> cir) {
        int alpha = XRay.getAlpha(state, null);
        if (alpha > 0 && alpha < 255) cir.setReturnValue(class_11515.field_60926);
    }

    @Inject(method = "getFluidLayer", at = @At("HEAD"), cancellable = true)
    private static void zeroHack$xrayGetFluidLayer(class_3610 state, CallbackInfoReturnable<class_11515> cir) {
        int alpha = XRay.getFluidAlpha(state, null);
        if (alpha > 0 && alpha < 255) cir.setReturnValue(class_11515.field_60926);
    }
}
