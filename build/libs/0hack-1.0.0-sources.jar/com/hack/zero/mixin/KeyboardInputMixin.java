package com.hack.zero.mixin;

import com.hack.zero.ZeroHack;
import com.hack.zero.module.render.Freecam;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void zeroHack$freezeInput(CallbackInfo ci) {
        Freecam freecam = getFreecam();
        if (freecam != null && freecam.isEnabled()) {
            InputAccessor input = (InputAccessor) (Object) this;
            input.setPlayerInput(class_10185.field_54098);
            input.setMovementVector(class_241.field_1340);
        }
    }

    private static Freecam getFreecam() {
        ZeroHack instance = ZeroHack.getInstance();
        if (instance == null) return null;
        return (Freecam) instance.getModuleManager().getModule("Freecam").orElse(null);
    }
}
