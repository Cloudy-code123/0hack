package com.hack.zero.mixin;

import com.hack.zero.module.movement.Velocity;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Unique
    private class_243 velocityPlus$scaleMovementInput(class_243 movementInput) {
        class_1309 self = (class_1309) (Object) this;
        if (!(self instanceof class_1657)) return movementInput;
        if (!self.method_37908().method_8608()) return movementInput;

        class_746 player = (class_746) self;
        Velocity velocity = getVelocityModule();
        if (velocity == null || !velocity.isEnabled()) return movementInput;

        velocity.tick(player);

        double multiplier = velocity.getCurrentEffectiveMultiplier();
        return new class_243(movementInput.field_1352 * multiplier, movementInput.field_1351, movementInput.field_1350 * multiplier);
    }

    @Unique
    private void velocityPlus$applyJumpBoost(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (!(self instanceof class_1657)) return;
        if (!self.method_37908().method_8608()) return;

        class_746 player = (class_746) self;
        Velocity velocity = getVelocityModule();
        if (velocity == null || !velocity.isEnabled()) return;
        if (!velocity.isJumpBoostEnabled()) return;

        velocity.onJump(player);
    }

    @Unique
    private void velocityPlus$cancelKnockback(double strength, double x, double z, CallbackInfo ci) {
        try {
            if (!((Object) this instanceof class_746)) return;
            Velocity velocity = getVelocityModule();
            if (velocity == null || !velocity.isEnabled()) return;
            ci.cancel();
        } catch (Exception ignored) {}
    }

    @Unique
    private Velocity getVelocityModule() {
        com.hack.zero.ZeroHack instance = com.hack.zero.ZeroHack.getInstance();
        if (instance == null) return null;
        return (Velocity) instance.getModuleManager().getModule("Velocity").orElse(null);
    }

    @ModifyVariable(method = "travel", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private class_243 modifyMovementInput(class_243 movementInput) {
        return velocityPlus$scaleMovementInput(movementInput);
    }

    @Inject(method = "jump", at = @At("HEAD"))
    private void onJump(CallbackInfo ci) {
        velocityPlus$applyJumpBoost(ci);
    }

    @Inject(method = "takeKnockback", at = @At("HEAD"), cancellable = true)
    private void onTakeKnockback(double strength, double x, double z, CallbackInfo ci) {
        velocityPlus$cancelKnockback(strength, x, z, ci);
    }
}
