package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_4588;
import net.minecraft.class_775;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_775.class)
public abstract class FluidRendererMixin {
    @Unique
    private static final ThreadLocal<Integer> FLUID_ALPHA = ThreadLocal.withInitial(() -> -1);

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void zeroHack$xrayRender(class_1920 world, class_2338 pos, class_4588 vertexConsumer, class_2680 blockState, class_3610 fluidState, CallbackInfo ci) {
        int alpha = XRay.getFluidAlpha(fluidState, pos);

        if (alpha == 0) ci.cancel();
        else FLUID_ALPHA.set(alpha);
    }

    @Inject(method = "vertex", at = @At("HEAD"), cancellable = true)
    private void zeroHack$xrayVertex(class_4588 vertexConsumer, float x, float y, float z, float red, float green, float blue, float u, float v, int light, CallbackInfo ci) {
        int alpha = FLUID_ALPHA.get();

        if (alpha != -1) {
            vertexConsumer.method_22912(x, y, z).method_1336((int) (red * 255), (int) (green * 255), (int) (blue * 255), alpha).method_22913(u, v).method_60803(light).method_22914(0.0F, 1.0F, 0.0F);
            ci.cancel();
        }
    }
}
