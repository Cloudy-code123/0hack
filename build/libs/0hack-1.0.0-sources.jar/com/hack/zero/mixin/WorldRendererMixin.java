package com.hack.zero.mixin;

import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_761.class)
public class WorldRendererMixin {
}
