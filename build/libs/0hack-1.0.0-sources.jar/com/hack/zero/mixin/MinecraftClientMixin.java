package com.hack.zero.mixin;

import com.hack.zero.ZeroHack;
import com.hack.zero.event.events.TickEvent;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        ZeroHack.getInstance().getEventManager().fire(new TickEvent());
    }
}
