package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_824.class)
public abstract class BlockEntityRenderDispatcherMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private <E extends class_2586> void zeroHack$xrayBlockEntity(E blockEntity, float tickProgress, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        if (XRay.isActive() && XRay.getAlpha(blockEntity.method_11010(), blockEntity.method_11016()) == 0) {
            ci.cancel();
        }
    }
}
