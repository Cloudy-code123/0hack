package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public abstract class BlockStateMixin {
    @Inject(method = "getOpacity", at = @At("HEAD"), cancellable = true)
    private void zeroHack$xrayOpacity(CallbackInfoReturnable<Integer> cir) {
        if (XRay.isActive()) cir.setReturnValue(0);
    }

    @Inject(method = "getAmbientOcclusionLightLevel", at = @At("HEAD"), cancellable = true)
    private void zeroHack$xrayAmbientOcclusion(class_1922 world, class_2338 pos, CallbackInfoReturnable<Float> cir) {
        if (XRay.isActive()) cir.setReturnValue(1.0F);
    }
}
