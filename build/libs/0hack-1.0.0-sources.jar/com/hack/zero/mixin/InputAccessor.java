package com.hack.zero.mixin;

import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_744.class)
public interface InputAccessor {
    @Accessor("playerInput")
    void setPlayerInput(class_10185 value);

    @Accessor("movementVector")
    void setMovementVector(class_241 value);
}
