package com.hack.zero.mixin;

import com.hack.zero.ZeroHack;
import com.hack.zero.module.render.Freecam;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(class_243 pos);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At("TAIL"))
    private void zeroHack$applyFreecam(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        Freecam freecam = getFreecam();
        if (freecam == null || !freecam.isEnabled()) return;

        setPos(new class_243(freecam.getX(tickDelta), freecam.getY(tickDelta), freecam.getZ(tickDelta)));
        setRotation((float) freecam.getYaw(tickDelta), (float) freecam.getPitch(tickDelta));
    }

    private static Freecam getFreecam() {
        ZeroHack instance = ZeroHack.getInstance();
        if (instance == null) return null;
        return (Freecam) instance.getModuleManager().getModule("Freecam").orElse(null);
    }
}
