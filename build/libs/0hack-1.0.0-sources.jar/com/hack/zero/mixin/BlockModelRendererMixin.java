package com.hack.zero.mixin;

import com.hack.zero.ZeroHack;
import com.hack.zero.module.render.XRay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_778;

@Mixin(class_778.class)
public class BlockModelRendererMixin {

    @Inject(method = "render(Lnet/minecraft/world/BlockRenderView;Ljava/util/List;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZI)V", at = @At("HEAD"), cancellable = true)
    private void onRender(class_1920 world, List<class_10889> parts, class_2680 state, class_2338 pos, net.minecraft.class_4587 matrices, net.minecraft.class_4588 vertexConsumer, boolean checkSides, int seed, CallbackInfo ci) {
        XRay xray = (XRay) ZeroHack.getInstance().getModuleManager().getModule("XRay").orElse(null);
        if (xray != null && xray.isEnabled() && !xray.shouldRender(state)) {
            ci.cancel();
        }
    }
}
