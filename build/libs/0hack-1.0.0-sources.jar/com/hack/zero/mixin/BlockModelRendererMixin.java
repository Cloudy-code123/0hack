package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_10889;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_778;

@Mixin(class_778.class)
public abstract class BlockModelRendererMixin {
    @Unique
    private static final ThreadLocal<Integer> ALPHA = ThreadLocal.withInitial(() -> -1);

    @Inject(method = {"renderSmooth", "renderFlat"}, at = @At("HEAD"), cancellable = true)
    private void zeroHack$xrayAlpha(class_1920 world, List<class_10889> parts, class_2680 state, class_2338 pos, class_4587 matrices, class_4588 vertexConsumer, boolean cull, int overlay, CallbackInfo ci) {
        int alpha = XRay.getAlpha(state, pos);

        if (alpha == 0) ci.cancel();
        else ALPHA.set(alpha);
    }

    @ModifyConstant(method = "renderQuad", constant = @Constant(floatValue = 1.0F, ordinal = 3))
    private float zeroHack$modifyQuadAlpha(float original) {
        int alpha = ALPHA.get();
        return alpha == -1 ? original : alpha / 255.0F;
    }
}
