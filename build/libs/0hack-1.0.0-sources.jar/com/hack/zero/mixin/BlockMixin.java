package com.hack.zero.mixin;

import com.hack.zero.module.render.XRay;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public abstract class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("RETURN"), cancellable = true)
    private static void zeroHack$xrayShouldDrawSide(class_2680 state, class_2680 otherState, class_2350 side, CallbackInfoReturnable<Boolean> cir) {
        XRay xray = XRay.getInstance();
        if (xray != null && xray.isEnabled()) {
            cir.setReturnValue(xray.modifyDrawSide(state, otherState, side, cir.getReturnValue()));
        }
    }
}
