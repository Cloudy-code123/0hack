package com.hack.zero.mixin;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
}
