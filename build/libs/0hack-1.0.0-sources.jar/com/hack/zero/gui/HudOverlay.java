package com.hack.zero.gui;

import com.hack.zero.ZeroHack;
import com.hack.zero.module.Module;
import com.hack.zero.util.ColorUtil;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class HudOverlay {
    private final class_310 mc = class_310.method_1551();

    public void render(class_332 context) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 instanceof ClickGui) return;

        renderArrayList(context);
        renderWatermark(context);
        renderCoordinates(context);
        renderStats(context);
    }

    private void renderArrayList(class_332 context) {
        List<Module> enabled = ZeroHack.getInstance().getModuleManager().getModules().stream()
                .filter(Module::isEnabled)
                .sorted(Comparator.comparingInt(m -> -mc.field_1772.method_1727(m.getName())))
                .collect(Collectors.toList());

        int y = 2;
        int screenWidth = mc.method_22683().method_4486();

        for (int i = 0; i < enabled.size(); i++) {
            Module mod = enabled.get(i);
            String name = mod.getName();
            String info = mod.getInfoString();
            String displayName = info != null ? name + " \u00a77" + info : name;
            int width = mc.field_1772.method_1727(displayName);
            int x = screenWidth - width - 4;

            int color = ColorUtil.rainbow(i * 30, 0.7f);

            context.method_25294(x - 2, y, screenWidth, y + 12, 0x80000000);
            context.method_25303(mc.field_1772, displayName, x, y + 2, color);

            y += 12;
        }
    }

    private void renderWatermark(class_332 context) {
        String text = "0hack v1.0";
        context.method_25294(2, 2, mc.field_1772.method_1727(text) + 6, 14, 0x80000000);
        context.method_25303(mc.field_1772, text, 4, 4, 0xFF00CCFF);
    }

    private void renderCoordinates(class_332 context) {
        if (mc.field_1724 == null) return;
        int y = mc.method_22683().method_4502() - 26;
        String coords = String.format("X: %.1f Y: %.1f Z: %.1f",
                mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        context.method_25294(2, y - 2, mc.field_1772.method_1727(coords) + 6, y + 10, 0x80000000);
        context.method_25303(mc.field_1772, coords, 4, y, 0xFFCCCCCC);
    }

    private void renderStats(class_332 context) {
        if (mc.field_1724 == null) return;
        int fps = mc.method_47599();
        int ping = 0;
        var entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        if (entry != null) {
            ping = entry.method_2959();
        }
        int y = mc.method_22683().method_4502() - 38;
        String stats = String.format("FPS: %d  Ping: %dms", fps, ping);
        context.method_25294(2, y - 2, mc.field_1772.method_1727(stats) + 6, y + 10, 0x80000000);
        context.method_25303(mc.field_1772, stats, 4, y, 0xFF00FF00);
    }
}
