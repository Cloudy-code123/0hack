package com.hack.zero.gui;

import com.hack.zero.module.setting.BlockListSetting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public class BlockListScreen extends class_437 {
    private static final int ROW_HEIGHT = 12;
    private static final int LIST_X = 120;
    private static final int LIST_WIDTH = 240;

    private final BlockListSetting setting;
    private final Runnable resetAction;
    private final List<class_2248> blocks;
    private class_342 search;
    private int scrollOffset;
    private String query = "";

    public BlockListScreen(BlockListSetting setting, Runnable resetAction) {
        super(class_2561.method_43470("Block List"));
        this.setting = setting;
        this.resetAction = resetAction;
        this.blocks = new ArrayList<>();
        class_7923.field_41175.forEach(blocks::add);
        blocks.sort(Comparator.comparing(block -> block.method_9518().getString()));
    }

    @Override
    protected void method_25426() {
        search = new class_342(this.field_22793, this.field_22789 / 2 - LIST_X, 20, LIST_WIDTH, 20, class_2561.method_43470("Search blocks"));
        search.method_1863(text -> {
            query = text.toLowerCase();
            scrollOffset = 0;
        });
        this.method_37063(search);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset"), button -> resetAction.run())
                .method_46434(this.field_22789 / 2 - LIST_X, this.field_22790 - 30, LIST_WIDTH / 2 - 2, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> this.method_25419())
                .method_46434(this.field_22789 / 2 + 2, this.field_22790 - 30, LIST_WIDTH / 2 - 2, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        int x = this.field_22789 / 2 - LIST_X;
        int y = 50;
        int row = 0;
        for (class_2248 block : blocks) {
            String name = block.method_9518().getString();
            if (!name.toLowerCase().contains(query)) continue;
            if (row++ < scrollOffset) continue;
            if (y > this.field_22790 - 40) break;

            boolean selected = setting.getValue().contains(block);
            context.method_25303(this.field_22793, name, x + 6, y, selected ? 0xFFFFFFFF : 0xFF909090);
            String marker = selected ? "[x]" : "[ ]";
            context.method_25303(this.field_22793, marker, x + LIST_WIDTH - 30, y, selected ? 0xFF55FF55 : 0xFFAAAAAA);
            y += ROW_HEIGHT;
        }

        String hint = "Scroll to browse, click to toggle";
        context.method_25300(this.field_22793, hint, this.field_22789 / 2, this.field_22790 - 10, 0xFF606060);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int x = this.field_22789 / 2 - LIST_X;
            int y = 50;
            int row = 0;
            for (class_2248 block : blocks) {
                String name = block.method_9518().getString();
                if (!name.toLowerCase().contains(query)) continue;
                if (row++ < scrollOffset) continue;
                if (y > this.field_22790 - 40) break;

                if (mouseX >= x && mouseX <= x + LIST_WIDTH && mouseY >= y && mouseY <= y + ROW_HEIGHT) {
                    if (setting.getValue().contains(block)) {
                        setting.getValue().remove(block);
                    } else {
                        setting.getValue().add(block);
                    }
                    return true;
                }
                y += ROW_HEIGHT;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset += (int) -verticalAmount;
        if (scrollOffset < 0) scrollOffset = 0;
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
