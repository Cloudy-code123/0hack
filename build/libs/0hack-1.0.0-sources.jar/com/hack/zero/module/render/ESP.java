package com.hack.zero.module.render;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1569;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_9866;
import net.minecraft.class_9974;

public final class ESP extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Box", "Box", "Outline", "Glow");
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", true);
    private final BooleanSetting animals = new BooleanSetting("Animals", true);
    private final BooleanSetting items = new BooleanSetting("Items", false);
    private final BooleanSetting chests = new BooleanSetting("Chests", true);
    private final BooleanSetting enderChests = new BooleanSetting("EnderChests", true);
    private final BooleanSetting furnaces = new BooleanSetting("Furnaces", true);
    private final BooleanSetting craftingTables = new BooleanSetting("CraftingTables", true);
    private final BooleanSetting shulkerBoxes = new BooleanSetting("ShulkerBoxes", true);

    public ESP() {
        super("ESP", "Highlights entities and blocks through walls.", Category.RENDER, 0);
        addSetting(mode);
        addSetting(players);
        addSetting(mobs);
        addSetting(animals);
        addSetting(items);
        addSetting(chests);
        addSetting(enderChests);
        addSetting(furnaces);
        addSetting(craftingTables);
        addSetting(shulkerBoxes);
    }

    @Override
    public void onRender3D(class_4587 matrices, float tickDelta, WorldRenderContext context) {
        if (mc.field_1687 == null || mc.field_1724 == null || context.consumers() == null) return;

        class_243 camera = context.camera().method_19326();

        RenderUtil.setupRenderState();
        try {
            // ★ uses the no-depth layer → sees through blocks
            class_4588 lines = context.consumers().getBuffer(RenderUtil.getEspLines());

            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity instanceof class_1542 && items.isOn()) {
                    class_238 itemBox = entity.method_5829().method_1014(0.04).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
                    class_9974.method_62295(context.matrixStack(), lines, itemBox, 0.2f, 0.8f, 1.0f, 1.0f);
                    continue;
                }

                if (!(entity instanceof class_1309 living) || living == mc.field_1724 || !living.method_5805() || !isAllowed(living)) {
                    continue;
                }

                class_238 box = living.method_5829().method_1014(0.04).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);

                float red, green, blue;
                if (living instanceof class_1657) {
                    red = 0.0f; green = 0.4f; blue = 1.0f;
                } else if (living instanceof class_1429 || living instanceof class_9866) {
                    red = 1.0f; green = 0.6f; blue = 0.0f;
                } else {
                    red = 1.0f; green = 0.2f; blue = 0.2f;
                }

                class_9974.method_62295(context.matrixStack(), lines, box, red, green, blue, 1.0f);
            }

            boolean anyBlocks = chests.isOn() || enderChests.isOn() || furnaces.isOn()
                    || craftingTables.isOn() || shulkerBoxes.isOn();
            if (anyBlocks) {
                renderBlockESP(context, camera);
            }
        } finally {
            RenderUtil.restoreRenderState();
        }
    }

    private void renderBlockESP(WorldRenderContext context, class_243 camera) {
        class_4587 stack = context.matrixStack();
        // ★ same no-depth layer
        class_4588 lines = context.consumers().getBuffer(RenderUtil.getEspLines());

        class_2338 origin = mc.field_1724.method_24515();
        for (class_2338 pos : class_2338.method_25996(origin, 64, 32, 64)) {
            class_2248 block = mc.field_1687.method_8320(pos).method_26204();
            float r = 0, g = 0, b = 0;
            boolean matched = false;

            if (chests.isOn() && (block == class_2246.field_10034 || block == class_2246.field_10380)) {
                r = 0.0f; g = 1.0f; b = 0.0f;
                matched = true;
            } else if (enderChests.isOn() && block == class_2246.field_10443) {
                r = 0.8f; g = 0.2f; b = 1.0f;
                matched = true;
            } else if (furnaces.isOn() && (block == class_2246.field_10181 || block == class_2246.field_16334 || block == class_2246.field_16333)) {
                r = 0.6f; g = 0.4f; b = 0.2f;
                matched = true;
            } else if (craftingTables.isOn() && block == class_2246.field_9980) {
                r = 1.0f; g = 1.0f; b = 0.0f;
                matched = true;
            } else if (shulkerBoxes.isOn() && block instanceof class_2480) {
                r = 1.0f; g = 1.0f; b = 1.0f;
                matched = true;
            }

            if (matched) {
                stack.method_22903();
                stack.method_22904(pos.method_10263() - camera.field_1352, pos.method_10264() - camera.field_1351, pos.method_10260() - camera.field_1350);
                class_9974.method_62292(stack, lines, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, r, g, b, 1.0f);
                stack.method_22909();
            }
        }
    }

    private boolean isAllowed(class_1309 entity) {
        if (entity instanceof class_1657) return players.isOn();
        if (entity instanceof class_1569 || entity instanceof class_1588) return mobs.isOn();
        if (entity instanceof class_1429 || entity instanceof class_9866) return animals.isOn();
        if (entity instanceof class_1308) return mobs.isOn();
        return false;
    }
}