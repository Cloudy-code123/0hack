package com.hack.zero.module.render;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.RenderUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2480;

public final class Tracers extends Module {
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting monsters = new BooleanSetting("Monsters", true);
    private final BooleanSetting animals = new BooleanSetting("Animals", true);
    private final BooleanSetting items = new BooleanSetting("Items", false);
    private final BooleanSetting chests = new BooleanSetting("Chests", true);
    private final BooleanSetting enderChests = new BooleanSetting("EnderChests", true);
    private final BooleanSetting shulkerBoxes = new BooleanSetting("ShulkerBoxes", true);
    private final BooleanSetting furnaces = new BooleanSetting("Furnaces", true);
    private final BooleanSetting craftingTables = new BooleanSetting("CraftingTables", true);
    private final NumberSetting thickness = new NumberSetting("Thickness", 1.0, 0.5, 5.0, 0.5);

    public Tracers() {
        super("Tracers", "Draws lines to nearby targets.", Category.RENDER, 0);
        addSetting(players);
        addSetting(monsters);
        addSetting(animals);
        addSetting(items);
        addSetting(chests);
        addSetting(enderChests);
        addSetting(shulkerBoxes);
        addSetting(furnaces);
        addSetting(craftingTables);
        addSetting(thickness);
    }

    @Override
    public void onRender3D(net.minecraft.class_4587 matrices, float tickDelta, WorldRenderContext context) {
        if (mc.field_1687 == null || mc.field_1724 == null || context.consumers() == null) {
            return;
        }
        class_243 camera = context.camera().method_19326();
        float camPitch = context.camera().method_19329();
        float camYaw = context.camera().method_19330();
        class_243 crosshair = new class_243(0.0, 0.0, 1.0)
                .method_1037((float) -Math.toRadians(camPitch))
                .method_1024((float) -Math.toRadians(camYaw));

        RenderUtil.setupRenderState();
        try {
            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity instanceof class_1542 && items.isOn()) {
                    class_243 target = entity.method_24515().method_46558().method_1020(camera);
                    drawTracer(context, crosshair, target, 0.2f, 0.8f, 1.0f);
                    continue;
                }
                if (!(entity instanceof class_1309 living) || living == mc.field_1724 || !living.method_5805() || !isAllowed(living)) {
                    continue;
                }
                class_243 target = living.method_24515().method_46558().method_1020(camera);
                float r, g, b;
                if (entity instanceof class_1657) {
                    r = 0.2f; g = 1.0f; b = 0.2f;
                } else if (entity instanceof class_1588) {
                    r = 1.0f; g = 0.3f; b = 0.2f;
                } else {
                    r = 0.2f; g = 0.8f; b = 1.0f;
                }
                drawTracer(context, crosshair, target, r, g, b);
            }
            class_2338 origin = mc.field_1724.method_24515();
            for (class_2338 pos : class_2338.method_25996(origin, 64, 32, 64)) {
                class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                class_243 target;
                if (chests.isOn() && (block == class_2246.field_10034 || block == class_2246.field_10380)) {
                    target = class_243.method_24953(pos).method_1020(camera);
                    drawTracer(context, crosshair, target, 1.0f, 0.8f, 0.2f);
                    continue;
                }
                if (enderChests.isOn() && block == class_2246.field_10443) {
                    target = class_243.method_24953(pos).method_1020(camera);
                    drawTracer(context, crosshair, target, 0.0f, 1.0f, 0.9f);
                    continue;
                }
                if (shulkerBoxes.isOn() && block instanceof class_2480) {
                    target = class_243.method_24953(pos).method_1020(camera);
                    drawTracer(context, crosshair, target, 0.8f, 0.2f, 1.0f);
                    continue;
                }
                if (furnaces.isOn() && (block == class_2246.field_10181 || block == class_2246.field_16334 || block == class_2246.field_16333)) {
                    target = class_243.method_24953(pos).method_1020(camera);
                    drawTracer(context, crosshair, target, 1.0f, 0.4f, 0.0f);
                    continue;
                }
                if (craftingTables.isOn() && block == class_2246.field_9980) {
                    target = class_243.method_24953(pos).method_1020(camera);
                    drawTracer(context, crosshair, target, 1.0f, 1.0f, 0.2f);
                }
            }
        } finally {
            RenderUtil.restoreRenderState();
        }
    }

    private void drawTracer(WorldRenderContext context, class_243 crosshair, class_243 target, float red, float green, float blue) {
        int color = 0xFF000000 | (int) (red * 255.0f) << 16 | (int) (green * 255.0f) << 8 | (int) (blue * 255.0f);
        RenderUtil.drawLine(context.matrixStack(), context.consumers(), crosshair, target, color);
    }

    private boolean isAllowed(class_1309 entity) {
        if (entity instanceof class_1657) return players.isOn();
        if (entity instanceof class_1588) return monsters.isOn();
        if (entity instanceof class_1429) return animals.isOn();
        return false;
    }
}
