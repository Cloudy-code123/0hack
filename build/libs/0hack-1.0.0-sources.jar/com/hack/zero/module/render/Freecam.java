package com.hack.zero.module.render;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_5498;
import net.minecraft.class_634;
import org.joml.Vector3d;

public class Freecam extends Module {
    private final ModeSetting viewMode = new ModeSetting("Mode", "First Person", "First Person", "Third Person");
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 20.0, 0.1);
    private final NumberSetting speedScrollSensitivity = new NumberSetting("Scroll Sensitivity", 0.0, 0.0, 2.0, 0.1);
    private final BooleanSetting staySneaking = new BooleanSetting("Stay Sneaking", true);
    private final BooleanSetting toggleOnDamage = new BooleanSetting("Toggle On Damage", false);
    private final BooleanSetting toggleOnDeath = new BooleanSetting("Toggle On Death", false);
    private final BooleanSetting toggleOnLog = new BooleanSetting("Toggle On Log", true);
    private final BooleanSetting reloadChunks = new BooleanSetting("Reload Chunks", true);
    private final BooleanSetting showHands = new BooleanSetting("Show Hands", true);
    private final BooleanSetting rotate = new BooleanSetting("Rotate", false);
    private final BooleanSetting staticView = new BooleanSetting("Static", true);
    private final BooleanSetting showPlayer = new BooleanSetting("Show Player", true);
    private final BooleanSetting movePlayer = new BooleanSetting("Move Player", false);

    public final Vector3d pos = new Vector3d();

    private class_5498 perspective;

    public float yaw, pitch;

    private double fovScale;
    private boolean bobView;

    private boolean isSneaking;
    private boolean lastPerspectiveKeyDown;

    private boolean wasNoClip;
    private boolean wasInvulnerable;

    private class_243 bodyPos;

    private float lastHealth;
    private class_5321<class_1937> lastDim;

    public Freecam() {
        super("Freecam", "Allows the camera to move away from the player.", Category.RENDER, 0);
        addSetting(viewMode);
        addSetting(speed);
        addSetting(speedScrollSensitivity);
        addSetting(staySneaking);
        addSetting(toggleOnDamage);
        addSetting(toggleOnDeath);
        addSetting(toggleOnLog);
        addSetting(reloadChunks);
        addSetting(showHands);
        addSetting(rotate);
        addSetting(staticView);
        addSetting(showPlayer);
        addSetting(movePlayer);

        ClientPlayConnectionEvents.DISCONNECT.register(this::onDisconnect);
        WorldRenderEvents.LAST.register(this::onWorldRender);
    }

    @Override
    public void onEnable() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            setEnabled(false);
            return;
        }

        fovScale = mc.field_1690.method_42454().method_41753();
        bobView = mc.field_1690.method_42448().method_41753();
        if (staticView.isOn()) {
            mc.field_1690.method_42454().method_41748(0.0);
            mc.field_1690.method_42448().method_41748(false);
        }

        yaw = mc.field_1724.method_36454();
        pitch = mc.field_1724.method_36455();

        perspective = mc.field_1690.method_31044();

        class_243 camPos = mc.field_1773.method_19418().method_71156();
        pos.set(camPos.field_1352, camPos.field_1351, camPos.field_1350);

        if (perspective.method_31035()) {
            yaw += 180;
            pitch *= -1;
        }

        isSneaking = mc.field_1690.field_1832.method_1434();

        wasNoClip = mc.field_1724.field_5960;
        wasInvulnerable = mc.field_1724.method_5655();
        bodyPos = mc.field_1724.method_19538();

        applyPerspectiveMode();
        mc.field_1724.method_5684(true);

        lastHealth = mc.field_1724.method_6032();
        lastDim = mc.field_1724.method_37908().method_27983();

        if (reloadChunks.isOn()) mc.field_1769.method_3279();
    }

    @Override
    public void onDisable() {
        if (reloadChunks.isOn() && mc.field_1769 != null) {
            mc.execute(mc.field_1769::method_3279);
        }

        if (perspective != null) {
            mc.field_1690.method_31043(perspective);
        }
        if (staticView.isOn()) {
            mc.field_1690.method_42454().method_41748(fovScale);
            mc.field_1690.method_42448().method_41748(bobView);
        }
        if (mc.field_1724 != null) {
            mc.field_1724.field_5960 = wasNoClip;
            mc.field_1724.method_5684(wasInvulnerable);
        }

        isSneaking = false;
        lastPerspectiveKeyDown = false;
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_1297 cameraEntity = mc.method_1560();
        if (cameraEntity != null && cameraEntity.method_5757()) {
            cameraEntity.field_5960 = true;
        }

        if (mc.field_1724 != null) {
            mc.field_1724.field_5960 = true;
            if (!movePlayer.isOn() && bodyPos != null) {
                mc.field_1724.method_5814(bodyPos.field_1352, bodyPos.field_1351, bodyPos.field_1350);
                mc.field_1724.method_18799(class_243.field_1353);
                mc.field_1724.field_6017 = 0.0f;
            }
        }

        boolean perspectiveKeyDown = mc.field_1690.field_1824.method_1434();
        if (perspectiveKeyDown && !lastPerspectiveKeyDown) {
            viewMode.cycle();
        }
        lastPerspectiveKeyDown = perspectiveKeyDown;

        if (perspective != null) {
            applyPerspectiveMode();
        }

        if (rotate.isOn()) rotatePlayer();

        if (toggleOnDeath.isOn() && mc.field_1724.method_29504()) {
            toggleOff("you died");
            return;
        }
        if (toggleOnDamage.isOn() && lastHealth > mc.field_1724.method_6032()) {
            toggleOff("you took damage");
            return;
        }
        lastHealth = mc.field_1724.method_6032();

        class_5321<class_1937> dim = mc.field_1724.method_37908().method_27983();
        if (lastDim != null && !lastDim.equals(dim)) {
            toggleOff("you changed dimensions");
            return;
        }
        lastDim = dim;
    }

    private void onWorldRender(WorldRenderContext context) {
        if (!isEnabled() || mc.method_1493()) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;

        float ticks = context.tickCounter().method_60636();
        if (ticks <= 0) return;
        if (ticks > 1.0f) ticks = 1.0f;

        boolean forward = mc.field_1690.field_1894.method_1434();
        boolean backward = mc.field_1690.field_1881.method_1434();
        boolean left = mc.field_1690.field_1913.method_1434();
        boolean right = mc.field_1690.field_1849.method_1434();
        boolean up = mc.field_1690.field_1903.method_1434();
        boolean down = mc.field_1690.field_1832.method_1434();

        double s = mc.field_1690.field_1867.method_1434() ? 1.0 : 0.5;
        double speedValue = speed.getValue();

        class_243 forwardDir = class_243.method_1030(0, yaw);
        class_243 rightDir = class_243.method_1030(0, yaw + 90);

        double moveX = 0, moveY = 0, moveZ = 0;
        if (forward) {
            moveX += forwardDir.field_1352 * s * speedValue;
            moveZ += forwardDir.field_1350 * s * speedValue;
        }
        if (backward) {
            moveX -= forwardDir.field_1352 * s * speedValue;
            moveZ -= forwardDir.field_1350 * s * speedValue;
        }
        if (right) {
            moveX += rightDir.field_1352 * s * speedValue;
            moveZ += rightDir.field_1350 * s * speedValue;
        }
        if (left) {
            moveX -= rightDir.field_1352 * s * speedValue;
            moveZ -= rightDir.field_1350 * s * speedValue;
        }

        if ((forward || backward) && (left || right)) {
            double diagonal = 1 / Math.sqrt(2);
            moveX *= diagonal;
            moveZ *= diagonal;
        }

        if (up) moveY += s * speedValue;
        if (down) moveY -= s * speedValue;

        pos.set(pos.x + moveX * ticks, pos.y + moveY * ticks, pos.z + moveZ * ticks);

        if (movePlayer.isOn() && mc.field_1724 != null) {
            mc.field_1724.field_5960 = true;
            mc.field_1724.method_36456(yaw);
            mc.field_1724.method_36457(pitch);
            mc.field_1724.method_5814(pos.x, pos.y - mc.field_1724.method_18381(mc.field_1724.method_18376()), pos.z);
            mc.field_1724.field_6017 = 0.0f;
        }
    }

    private void rotatePlayer() {
        class_239 hit = mc.field_1765;
        if (hit == null || hit.method_17783() == class_239.class_240.field_1333) return;

        class_243 eye = mc.field_1773.method_19418().method_71156();
        class_243 target = hit.method_17784();

        double dx = target.field_1352 - eye.field_1352;
        double dy = target.field_1351 - eye.field_1351;
        double dz = target.field_1350 - eye.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        mc.field_1724.method_36456(targetYaw);
        mc.field_1724.method_36457(class_3532.method_15363(targetPitch, -90.0f, 90.0f));
    }

    private void toggleOff(String reason) {
        setEnabled(false);
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470("[0hack] Freecam disabled (" + reason + ")."), false);
        }
    }

    private void onDisconnect(class_634 handler, class_310 client) {
        if (toggleOnLog.isOn() && isEnabled()) {
            setEnabled(false);
        }
    }

    public boolean onScroll(double amount) {
        if (speedScrollSensitivity.getValue() > 0) {
            double next = speed.getValue() + amount * 0.25 * (speedScrollSensitivity.getValue() * speed.getValue());
            speed.setValue(class_3532.method_15350(next, speed.getMin(), speed.getMax()));
            return true;
        }
        return false;
    }

    public void changeLookDirection(double deltaX, double deltaY) {
        yaw += (float) deltaX;
        pitch += (float) deltaY;

        pitch = class_3532.method_15363(pitch, -90, 90);
    }

    public boolean renderHands() {
        return !isEnabled() || showHands.isOn();
    }

    public boolean showPlayer() {
        return isEnabled() && isThirdPersonMode() && showPlayer.isOn();
    }

    private boolean isThirdPersonMode() {
        return "Third Person".equals(viewMode.getValue());
    }

    private void applyPerspectiveMode() {
        mc.field_1690.method_31043(isThirdPersonMode() ? class_5498.field_26665 : class_5498.field_26664);
    }

    public boolean staySneaking() {
        return isEnabled() && mc.field_1724 != null && !mc.field_1724.method_31549().field_7479 && staySneaking.isOn() && isSneaking;
    }

    public double getX(float tickDelta) {
        return pos.x;
    }

    public double getY(float tickDelta) {
        return pos.y;
    }

    public double getZ(float tickDelta) {
        return pos.z;
    }

    public double getYaw(float tickDelta) {
        return yaw;
    }

    public double getPitch(float tickDelta) {
        return pitch;
    }
}
