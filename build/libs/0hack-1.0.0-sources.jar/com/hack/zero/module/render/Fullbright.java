package com.hack.zero.module.render;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class Fullbright extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Both", "Gamma", "Potion", "Both");
    private final NumberSetting gammaValue = new NumberSetting("Gamma", 1.0, 0.1, 1.0, 0.1);

    private double originalGamma;
    private boolean hadNightVision;

    private static final int NIGHT_VISION_DURATION = 600;
    private static final int NIGHT_VISION_REFRESH_THRESHOLD = 200;

    public Fullbright() {
        super("Fullbright", "See in the dark", Category.RENDER, 0);
        addSetting(mode);
        addSetting(gammaValue);
        setExpandable(false);
    }

    @Override
    protected void onEnable() {
        if (mc.field_1690 != null) {
            originalGamma = mc.field_1690.method_42473().method_41753();
        }
        if (mc.field_1724 != null) {
            hadNightVision = mc.field_1724.method_6059(class_1294.field_5925);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.field_1690 != null) {
            mc.field_1690.method_42473().method_41748(originalGamma);
        }
        if (mc.field_1724 != null) {
            mc.field_1724.method_6016(class_1294.field_5925);
            if (hadNightVision) {
                mc.field_1724.method_6092(new class_1293(
                        class_1294.field_5925, NIGHT_VISION_REFRESH_THRESHOLD, 0, true, false, false));
            }
            hadNightVision = false;
        }
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1690 == null) return;

        String modeVal = mode.getValue();

        if ("Gamma".equals(modeVal) || "Both".equals(modeVal)) {
            mc.field_1690.method_42473().method_41748(Math.min(gammaValue.getValue(), 1.0));
        }

        if ("Potion".equals(modeVal) || "Both".equals(modeVal)) {
            class_1293 current = mc.field_1724.method_6112(class_1294.field_5925);
            if (current == null || current.method_5584() <= NIGHT_VISION_REFRESH_THRESHOLD) {
                mc.field_1724.method_6092(new class_1293(
                        class_1294.field_5925, NIGHT_VISION_DURATION, 0, true, false, false));
            }
        }
    }
}
