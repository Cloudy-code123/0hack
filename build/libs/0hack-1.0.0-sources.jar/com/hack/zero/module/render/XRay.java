package com.hack.zero.module.render;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;

public class XRay extends Module {
    private static XRay INSTANCE;

    private static final Set<class_2248> DEFAULT_ORES = new HashSet<>();
    static {
        DEFAULT_ORES.add(class_2246.field_10418); DEFAULT_ORES.add(class_2246.field_29219);
        DEFAULT_ORES.add(class_2246.field_10212); DEFAULT_ORES.add(class_2246.field_29027);
        DEFAULT_ORES.add(class_2246.field_10571); DEFAULT_ORES.add(class_2246.field_29026);
        DEFAULT_ORES.add(class_2246.field_10090); DEFAULT_ORES.add(class_2246.field_29028);
        DEFAULT_ORES.add(class_2246.field_10080); DEFAULT_ORES.add(class_2246.field_29030);
        DEFAULT_ORES.add(class_2246.field_10442); DEFAULT_ORES.add(class_2246.field_29029);
        DEFAULT_ORES.add(class_2246.field_10013); DEFAULT_ORES.add(class_2246.field_29220);
        DEFAULT_ORES.add(class_2246.field_27120); DEFAULT_ORES.add(class_2246.field_29221);
        DEFAULT_ORES.add(class_2246.field_23077); DEFAULT_ORES.add(class_2246.field_10213);
        DEFAULT_ORES.add(class_2246.field_22109);
        DEFAULT_ORES.add(class_2246.field_33508); DEFAULT_ORES.add(class_2246.field_33510);
        DEFAULT_ORES.add(class_2246.field_33509);
        DEFAULT_ORES.add(class_2246.field_10034); DEFAULT_ORES.add(class_2246.field_10443);
        DEFAULT_ORES.add(class_2246.field_10380); DEFAULT_ORES.add(class_2246.field_16328);
        DEFAULT_ORES.add(class_2246.field_10200); DEFAULT_ORES.add(class_2246.field_10228);
        DEFAULT_ORES.add(class_2246.field_10312); DEFAULT_ORES.add(class_2246.field_10603);
        DEFAULT_ORES.add(class_2246.field_28888);
    }

    private final Set<class_2248> blocks = new HashSet<>(DEFAULT_ORES);
    private final NumberSetting opacity = new NumberSetting("Opacity", 25.0, 0.0, 255.0, 1.0);
    private final ModeSetting fluidOpacity = new ModeSetting("FluidOpacity", "Both", "None", "Water", "Lava", "Both");
    private final BooleanSetting containers = new BooleanSetting("Containers", true);

    public XRay() {
        super("XRay", "Only renders specified blocks. Good for mining.", Category.RENDER, 0);
        addSetting(opacity);
        addSetting(fluidOpacity);
        addSetting(containers);
        INSTANCE = this;
    }

    public static XRay getInstance() {
        return INSTANCE;
    }

    @Override
    protected void onEnable() {
        mc.field_1769.method_3279();
    }

    @Override
    protected void onDisable() {
        mc.field_1769.method_3279();
    }

    public void addBlock(class_2248 block) {
        blocks.add(block);
        if (isEnabled()) mc.field_1769.method_3279();
    }

    public void removeBlock(class_2248 block) {
        blocks.remove(block);
        if (isEnabled()) mc.field_1769.method_3279();
    }

    public Set<class_2248> getBlocks() {
        return blocks;
    }

    public boolean isBlocked(class_2248 block, class_2338 pos) {
        return !blocks.contains(block);
    }

    public boolean isWhitelisted(class_2680 state) {
        if (!isEnabled()) return true;
        class_2248 block = state.method_26204();
        return blocks.contains(block) || block == class_2246.field_10124 || block == class_2246.field_10543 || block == class_2246.field_10243
                || block == class_2246.field_10382 || block == class_2246.field_10164;
    }

    public boolean shouldRender(class_2680 state) {
        if (!isEnabled()) return true;
        class_2248 block = state.method_26204();
        return blocks.contains(block) || block == class_2246.field_10124 || block == class_2246.field_10543 || block == class_2246.field_10243
                || block == class_2246.field_10382 || block == class_2246.field_10164;
    }

    public static int getAlpha(class_2680 state, class_2338 pos) {
        XRay xray = INSTANCE;
        if (xray == null || !xray.isEnabled()) return -1;

        class_2248 block = state.method_26204();
        if (block == class_2246.field_10124 || block == class_2246.field_10543 || block == class_2246.field_10243
                || block == class_2246.field_10382 || block == class_2246.field_10164) return -1;

        if (!xray.blocks.contains(block)) {
            return xray.opacity.getInt();
        }

        return -1;
    }

    public static int getFluidAlpha(class_3610 state, class_2338 pos) {
        XRay xray = INSTANCE;
        if (xray == null || !xray.isEnabled()) return -1;
        if (xray.shouldApplyFluidOpacity(state)) {
            return xray.opacity.getInt();
        }
        return -1;
    }

    private boolean shouldApplyFluidOpacity(class_3610 state) {
        return switch (fluidOpacity.getValue()) {
            case "None" -> false;
            case "Water" -> state.method_15767(class_3486.field_15517);
            case "Lava" -> state.method_15767(class_3486.field_15518);
            case "Both" -> state.method_15767(class_3486.field_15517) || state.method_15767(class_3486.field_15518);
            default -> false;
        };
    }

    public int getOpacityValue() {
        return opacity.getInt();
    }

    public float getOpacityFloat() {
        return opacity.getFloat() / 255.0f;
    }
}
