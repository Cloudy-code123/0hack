package com.hack.zero.module.render;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BlockListSetting;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.BlockUtils;
import java.util.HashSet;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;

public final class XRay extends Module {
    public static final List<class_2248> ORES = List.of(
            class_2246.field_10418, class_2246.field_29219,
            class_2246.field_10212, class_2246.field_29027,
            class_2246.field_10571, class_2246.field_29026,
            class_2246.field_10090, class_2246.field_29028,
            class_2246.field_10080, class_2246.field_29030,
            class_2246.field_10442, class_2246.field_29029,
            class_2246.field_10013, class_2246.field_29220,
            class_2246.field_27120, class_2246.field_29221,
            class_2246.field_23077, class_2246.field_10213,
            class_2246.field_22109
    );

    private static XRay INSTANCE;

    private final BlockListSetting blocks = new BlockListSetting("Whitelist", new HashSet<>(ORES));
    private final NumberSetting opacity = new NumberSetting("Opacity", 25, 0, 255, 1);
    private final ModeSetting fluidOpacity = new ModeSetting("Fluid Opacity", "Both", "None", "Water", "Lava", "Both");
    private final BooleanSetting exposedOnly = new BooleanSetting("Exposed Only", false);

    public XRay() {
        super("XRay", "Only renders specified blocks. Good for mining.", Category.RENDER, 0);
        INSTANCE = this;
        addSetting(blocks);
        addSetting(opacity);
        addSetting(fluidOpacity);
        addSetting(exposedOnly);
    }

    public static XRay getInstance() {
        return INSTANCE;
    }

    public static boolean isActive() {
        return INSTANCE != null && INSTANCE.isEnabled();
    }

    public BlockListSetting getWhitelistSetting() {
        return blocks;
    }

    public void addBlock(class_2248 block) {
        blocks.getValue().add(block);
    }

    public void removeBlock(class_2248 block) {
        blocks.getValue().remove(block);
    }

    public void resetBlocks() {
        blocks.getValue().clear();
        blocks.getValue().addAll(ORES);
    }

    @Override
    protected void onEnable() {
        reloadWorldRenderer();
    }

    @Override
    protected void onDisable() {
        reloadWorldRenderer();
    }

    private void reloadWorldRenderer() {
        if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
    }

    public boolean modifyDrawSide(class_2680 state, class_2680 otherState, class_2350 facing, boolean returns) {
        if (!returns && !isBlocked(state, otherState)) {
            return otherState.method_26173(facing.method_10153()) != class_259.method_1077()
                    || otherState.method_26204() != state.method_26204()
                    || !otherState.method_26225();
        }

        return returns;
    }

    public boolean isBlocked(class_2248 block, class_2338 blockPos) {
        return !(blocks.contains(block) && (!exposedOnly.isOn() || (blockPos == null || BlockUtils.isExposed(blockPos))));
    }

    public boolean isBlocked(class_2680 state, class_2680 otherState) {
        return !(blocks.contains(state.method_26204()) && (!exposedOnly.isOn() || !otherState.method_26225()));
    }

    public static int getAlpha(class_2680 state, class_2338 pos) {
        XRay xray = INSTANCE;
        if (xray == null || !xray.isEnabled()) return -1;

        if (xray.isBlocked(state.method_26204(), pos)) {
            return xray.opacity.getInt();
        }

        return -1;
    }

    public static int getFluidAlpha(class_3610 state, class_2338 pos) {
        XRay xray = INSTANCE;
        if (xray == null || !xray.isEnabled()) return -1;

        class_2248 fluidBlock = state.method_15759().method_26204();
        if (xray.shouldApplyFluidOpacity(state) && xray.isBlocked(fluidBlock, pos)) {
            return xray.opacity.getInt();
        }

        return -1;
    }

    private boolean shouldApplyFluidOpacity(class_3610 state) {
        return switch (fluidOpacity.getValue()) {
            case "None" -> false;
            case "Water" -> state.method_15767(class_3486.field_15517);
            case "Lava" -> state.method_15767(class_3486.field_15518);
            default -> state.method_15767(class_3486.field_15517) || state.method_15767(class_3486.field_15518);
        };
    }
}
