package com.hack.zero.module.movement;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.PlayerUtil;
import net.minecraft.class_243;
import com.hack.zero.ZeroHack;

public class Speed extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Strafe", "Strafe", "Ground");
    private final NumberSetting speed = new NumberSetting("Speed", 1.5, 0.0, 2.0, 0.1);
    private final BooleanSetting sprint = new BooleanSetting("Sprint", true);
    private final BooleanSetting onlyOnGround = new BooleanSetting("OnlyOnGround", false);
    private final BooleanSetting inWater = new BooleanSetting("InWater", false);
    private final NumberSetting waterMultiplier = new NumberSetting("WaterMult", 0.7, 0.1, 1.0, 0.05);

    private int stage = 4;
    private double moveSpeed;
    private double lastDist;

    public Speed() {
        super("Speed", "Makes you go faster", Category.MOVEMENT, 0);
        addSetting(mode);
        addSetting(speed);
        addSetting(sprint);
        addSetting(onlyOnGround);
        addSetting(inWater);
        addSetting(waterMultiplier);
    }

    @Override
    protected void onEnable() {
        stage = 4;
        moveSpeed = 0;
        lastDist = 0;
    }

    @Override
    protected void onDisable() {
        stage = 4;
        moveSpeed = 0;
        lastDist = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (ZeroHack.getInstance().getModuleManager().getModule("Fly").map(Module::isEnabled).orElse(false)) return;

        if (onlyOnGround.isOn() && !mc.field_1724.method_24828() && !inWater.isOn()) return;
        if (!inWater.isOn() && mc.field_1724.method_5799()) return;

        if (sprint.isOn()) mc.field_1724.method_5728(true);

        double x = mc.field_1724.method_23317() - mc.field_1724.field_6014;
        double z = mc.field_1724.method_23321() - mc.field_1724.field_5969;
        lastDist = Math.sqrt(x * x + z * z);

        boolean onWater = mc.field_1724.method_5799();

        switch (mode.getValue()) {
            case "Strafe" -> strafe(onWater);
            case "Ground" -> ground(onWater);
        }
    }

    private void strafe(boolean onWater) {
        if (PlayerUtil.isMoving()) {
            if (mc.field_1724.method_24828()) stage = 2;

            if (stage == 1) {
                moveSpeed = speed.getValue() * 0.35;
            } else if (stage == 2) {
                moveSpeed = speed.getValue() * 0.6;
                stage = 3;
            } else if (stage == 3) {
                moveSpeed = lastDist - 0.66 * (lastDist - 0.2873);
                stage = 4;
            } else {
                moveSpeed = lastDist - lastDist / 159.0;
            }

            moveSpeed = Math.max(moveSpeed, 0.2873);

            if (onWater) {
                moveSpeed *= waterMultiplier.getValue();
            }

            double forward = mc.field_1724.field_6250;
            double strafe = mc.field_1724.field_6212;
            float yaw = mc.field_1724.method_36454();

            if (forward == 0 && strafe == 0) {
                mc.field_1724.method_18800(0, mc.field_1724.method_18798().field_1351, 0);
            } else {
                if (forward != 0) {
                    if (strafe > 0) yaw += (forward > 0 ? -45 : 45);
                    else if (strafe < 0) yaw += (forward > 0 ? 45 : -45);
                    strafe = 0;
                    if (forward > 0) forward = 1;
                    else if (forward < 0) forward = -1;
                }

                double rad = Math.toRadians(yaw + 90);
                double sin = Math.sin(rad);
                double cos = Math.cos(rad);

                mc.field_1724.method_18800(forward * moveSpeed * cos + strafe * moveSpeed * sin,
                    mc.field_1724.method_18798().field_1351,
                    forward * moveSpeed * sin - strafe * moveSpeed * cos);
            }
        } else {
            mc.field_1724.method_18800(0, mc.field_1724.method_18798().field_1351, 0);
        }

        stage++;
    }

    private void ground(boolean onWater) {
        if (PlayerUtil.isMoving()) {
            double mult = onWater ? waterMultiplier.getValue() : 1.0;
            class_243 vel = class_243.method_1030(0, mc.field_1724.method_36454()).method_1029().method_1021(speed.getValue() / 10 * mult);
            mc.field_1724.method_18800(vel.field_1352, mc.field_1724.method_18798().field_1351, vel.field_1350);
        }
    }
}
