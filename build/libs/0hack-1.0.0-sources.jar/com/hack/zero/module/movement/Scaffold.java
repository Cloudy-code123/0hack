package com.hack.zero.module.movement;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3965;

public class Scaffold extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Paving", "Tower");
    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 2.0, 1.0);
    private final BooleanSetting rotate = new BooleanSetting("Rotate", true);
    private final BooleanSetting sprint = new BooleanSetting("Sprint", true);
    private int ticks;

    public Scaffold() {
        super("Scaffold", "Strict single-block depth placement engine", Category.MOVEMENT, 0);
        addSetting(mode);
        addSetting(delay);
        addSetting(rotate);
        addSetting(sprint);
    }

    @Override
    protected void onEnable() {
        ticks = 0;
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null) return;

        if ("Tower".equals(mode.getValue()) && mc.field_1690.field_1903.method_1434()
                && mc.field_1724.method_18798().field_1351 < 0.3) {
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42, mc.field_1724.method_18798().field_1350);
        }

        tryPlaceBlock();
    }

    private void tryPlaceBlock() {
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1687 == null || mc.field_1724.field_3944 == null) {
            return;
        }
        if (ticks++ % (delay.getInt() + 1) != 0) {
            return;
        }
        mc.field_1724.method_5728(sprint.isOn());

        int blockSlot = findBlockSlot();
        if (blockSlot == -1) {
            return;
        }

        int targetY = (int) Math.floor(mc.field_1724.method_23318() - 1.0);
        if (mc.field_1724.method_18798().field_1351 < -0.1) {
            targetY = (int) Math.floor(mc.field_1724.method_23318() - 0.5);
        }

        if ("Paving".equals(mode.getValue())) {
            class_2338 playerFloor = new class_2338(
                    (int) Math.floor(mc.field_1724.method_23317()),
                    targetY,
                    (int) Math.floor(mc.field_1724.method_23321()));
            for (int xOffset = -2; xOffset <= 3; xOffset++) {
                for (int zOffset = -2; zOffset <= 3; zOffset++) {
                    class_2338 checkPos = playerFloor.method_10069(xOffset, 0, zOffset);
                    if (!mc.field_1687.method_8320(checkPos).method_26215()) continue;
                    class_2338 support = findSupportBlock(checkPos);
                    if (support == null) continue;
                    placeSingleBlock(checkPos, support, blockSlot);
                }
            }
            return;
        }

        double factor = 1.1;
        double motionX = mc.field_1724.method_18798().field_1352 * factor;
        double motionZ = mc.field_1724.method_18798().field_1350 * factor;
        class_238 playerBox = mc.field_1724.method_5829().method_1009(motionX, 0.0, motionZ);

        class_2338 targetPos = null;
        for (double x = playerBox.field_1323; x <= playerBox.field_1320; x += 0.3) {
            for (double z = playerBox.field_1321; z <= playerBox.field_1324; z += 0.3) {
                class_2338 checkPos = new class_2338((int) Math.floor(x), targetY, (int) Math.floor(z));
                if (!mc.field_1687.method_8320(checkPos).method_26215()) continue;
                if (findSupportBlock(checkPos) == null) continue;
                targetPos = checkPos;
                break;
            }
            if (targetPos != null) break;
        }

        if (targetPos == null) {
            return;
        }

        class_2338 support = findSupportBlock(targetPos);
        if (support == null) {
            return;
        }

        placeSingleBlock(targetPos, support, blockSlot);
    }

    private void placeSingleBlock(class_2338 targetPos, class_2338 support, int blockSlot) {
        class_2350 side = getPlaceDirection(targetPos, support);
        class_243 hitVec = class_243.method_24953(support).method_1019(
                new class_243(side.method_62675()).method_1021(0.5));

        if (rotate.isOn()) {
            mc.field_1724.field_3944.method_52787(
                    new class_2828.class_2831(
                            mc.field_1724.method_36454(), 82.5f,
                            mc.field_1724.method_24828(), mc.field_1724.field_5976));
        }

        int previousSlot = mc.field_1724.method_31548().method_67532();
        mc.field_1724.method_31548().method_61496(blockSlot);

        class_3965 hitResult = new class_3965(hitVec, side, support, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
        mc.field_1724.method_6104(class_1268.field_5808);

        mc.field_1724.method_31548().method_61496(previousSlot);
    }

    private class_2338 findSupportBlock(class_2338 target) {
        if (!mc.field_1687.method_8320(target.method_10074()).method_26215()) return target.method_10074();
        if (!mc.field_1687.method_8320(target.method_10095()).method_26215()) return target.method_10095();
        if (!mc.field_1687.method_8320(target.method_10078()).method_26215()) return target.method_10078();
        if (!mc.field_1687.method_8320(target.method_10072()).method_26215()) return target.method_10072();
        if (!mc.field_1687.method_8320(target.method_10067()).method_26215()) return target.method_10067();

        class_2338 downPos = target.method_10074();
        if (!mc.field_1687.method_8320(downPos.method_10095()).method_26215()) return downPos.method_10095();
        if (!mc.field_1687.method_8320(downPos.method_10078()).method_26215()) return downPos.method_10078();
        if (!mc.field_1687.method_8320(downPos.method_10072()).method_26215()) return downPos.method_10072();
        if (!mc.field_1687.method_8320(downPos.method_10067()).method_26215()) return downPos.method_10067();

        return null;
    }

    private class_2350 getPlaceDirection(class_2338 target, class_2338 support) {
        if (target.method_10264() > support.method_10264()) return class_2350.field_11036;
        if (target.method_10260() > support.method_10260()) return class_2350.field_11035;
        if (target.method_10260() < support.method_10260()) return class_2350.field_11043;
        if (target.method_10263() > support.method_10263()) return class_2350.field_11034;
        return class_2350.field_11039;
    }

    private int findBlockSlot() {
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) continue;
            if (!(stack.method_7909() instanceof class_1747 blockItem)) continue;
            if (blockItem.method_7711() == net.minecraft.class_2246.field_10124) continue;
            if (!blockItem.method_7711().method_9564().method_26212(mc.field_1687, class_2338.field_10980)) continue;
            return slot;
        }
        return -1;
    }
}
