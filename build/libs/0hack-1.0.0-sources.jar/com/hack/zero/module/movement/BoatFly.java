package com.hack.zero.module.movement;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.PacketUtil;
import com.hack.zero.util.PlayerUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_243;

public class BoatFly extends Module {
    private final NumberSetting hSpeed = new NumberSetting("Horizontal Speed", 1.5, 0.1, 5.0, 0.1);
    private final NumberSetting vSpeed = new NumberSetting("Vertical Speed", 1.0, 0.1, 3.0, 0.1);
    private final BooleanSetting antiKick = new BooleanSetting("AntiKick", true);
    private int tickCounter = 0;

    public BoatFly() {
        super("BoatFly", "Fly while in a boat. Adjust horizontal and vertical speed", Category.MOVEMENT, 0);
        addSetting(hSpeed);
        addSetting(vSpeed);
        addSetting(antiKick);
    }

    @Override
    protected void onEnable() {
        tickCounter = 0;
    }

    @Override
    protected void onDisable() {
        tickCounter = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!mc.field_1724.method_5765()) return;

        class_1297 vehicle = mc.field_1724.method_5854();
        if (!(vehicle instanceof class_1690 boat)) return;

        class_243 forward = class_243.method_1030(0, mc.field_1724.method_36454()).method_1029();
        class_243 strafe = class_243.method_1030(0, mc.field_1724.method_36454() - 90).method_1029();

        float inputForward = PlayerUtil.getInputForward();
        float inputSideways = PlayerUtil.getInputSideways();

        double moveX = 0, moveZ = 0, moveY = 0;

        if (inputForward != 0) {
            moveX += forward.field_1352 * inputForward * hSpeed.getValue();
            moveZ += forward.field_1350 * inputForward * hSpeed.getValue();
        }
        if (inputSideways != 0) {
            moveX += strafe.field_1352 * inputSideways * hSpeed.getValue();
            moveZ += strafe.field_1350 * inputSideways * hSpeed.getValue();
        }

        if (mc.field_1690.field_1903.method_1434()) moveY = vSpeed.getValue();
        if (mc.field_1690.field_1832.method_1434()) moveY = -vSpeed.getValue();

        boat.method_18800(moveX, moveY, moveZ);
        boat.method_5875(true);
        boat.field_6017 = 0;

        if (antiKick.isOn() && tickCounter % 20 == 0) {
            PacketUtil.sendPosition(boat.method_23317(), boat.method_23318() - 0.04, boat.method_23321(), true);
        }

        tickCounter++;
    }
}
