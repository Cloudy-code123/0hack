package com.hack.zero.module.movement;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.ModeSetting;
import net.minecraft.class_2828;

public class NoFall extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Packet", "Packet", "MLG", "Cancel");

    public NoFall() {
        super("NoFall", "Prevents fall damage on the client side", Category.MOVEMENT, 0);
        addSetting(mode);
        setExpandable(false);
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) return;

        if (mc.field_1724.field_6017 > 0.0f) {
            mc.field_1724.field_6017 = 0.0f;
        }

        mc.field_1724.field_3944.method_52787(
                new class_2828.class_5911(true, false));
    }
}
