package com.hack.zero.module.movement;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.PacketUtil;
import com.hack.zero.util.PlayerUtil;
import net.minecraft.class_243;

public class Fly extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Packet", "Glide");
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 6.0, 0.1);
    private final BooleanSetting antiKick = new BooleanSetting("AntiKick", true);
    private final NumberSetting glideSpeed = new NumberSetting("GlideSpeed", -0.04, -0.1, 0.0, 0.005);
    private int tickCounter = 0;

    public Fly() {
        super("Fly", "Fly around the map. Modes: Vanilla, Packet, Glide", Category.MOVEMENT, 70);
        addSetting(mode);
        addSetting(speed);
        addSetting(antiKick);
        addSetting(glideSpeed);
    }

    @Override
    protected void onEnable() {
        tickCounter = 0;
    }

    @Override
    protected void onDisable() {
        if (mc.field_1724 != null) {
            mc.field_1724.method_31549().field_7479 = false;
            mc.field_1724.method_18799(class_243.field_1353);
        }
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1724.method_6128()) return;

        mc.field_1724.method_31549().field_7479 = false;
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352 * 0.95, mc.field_1724.method_18798().field_1351 * 0.95, mc.field_1724.method_18798().field_1350 * 0.95);

        class_243 forward = class_243.method_1030(0, mc.field_1724.method_36454()).method_1029();
        class_243 strafe = class_243.method_1030(0, mc.field_1724.method_36454() - 90).method_1029();

        float inputForward = PlayerUtil.getInputForward();
        float inputSideways = PlayerUtil.getInputSideways();

        double moveX = 0, moveZ = 0, moveY = 0;
        if (inputForward != 0) {
            moveX += forward.field_1352 * inputForward;
            moveZ += forward.field_1350 * inputForward;
        }
        if (inputSideways != 0) {
            moveX += strafe.field_1352 * inputSideways;
            moveZ += strafe.field_1350 * inputSideways;
        }

        double len = Math.sqrt(moveX * moveX + moveZ * moveZ);
        if (len > 0) {
            moveX = moveX / len * speed.getValue();
            moveZ = moveZ / len * speed.getValue();
        }

        if (mc.field_1690.field_1903.method_1434()) moveY = speed.getValue() * 0.5;
        if (mc.field_1690.field_1832.method_1434()) moveY = -speed.getValue() * 0.5;

        switch (mode.getValue()) {
            case "Vanilla" -> {
                mc.field_1724.method_18800(moveX, moveY, moveZ);
            }
            case "Packet" -> {
                mc.field_1724.method_18800(moveX, moveY, moveZ);
                if (tickCounter % 20 == 0 && antiKick.isOn()) {
                    PacketUtil.sendPosition(mc.field_1724.method_23317(), mc.field_1724.method_23318() - 0.04, mc.field_1724.method_23321(), true);
                }
                tickCounter++;
            }
            case "Glide" -> {
                double yVelocity = mc.field_1724.method_18798().field_1351;
                if (inputForward != 0 || inputSideways != 0) {
                    mc.field_1724.method_18800(moveX, Math.max(yVelocity, glideSpeed.getValue()), moveZ);
                } else {
                    mc.field_1724.method_18800(0, glideSpeed.getValue(), 0);
                }
            }
        }
    }
}
