package com.hack.zero.module.movement;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.PacketUtil;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class Jesus extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Solid", "Solid", "Bounce", "NCP");
    private final NumberSetting motionY = new NumberSetting("MotionY", 0.1, 0.01, 0.5, 0.01);
    private final BooleanSetting sink = new BooleanSetting("AntiSink", true);

    public Jesus() {
        super("Jesus", "Walk on water and lava", Category.MOVEMENT, 0);
        addSetting(mode);
        addSetting(motionY);
        addSetting(sink);
        setExpandable(false);
    }

    @Override
    protected void onEnable() {}

    @Override
    protected void onDisable() {
        if (mc.field_1724 != null) {
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0, mc.field_1724.method_18798().field_1350);
        }
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1724.method_5869() || mc.field_1724.method_5771()) return;

        class_243 pos = mc.field_1724.method_19538();
        class_2338 blockBelow = new class_2338((int) pos.field_1352, (int) (pos.field_1351 - 0.1), (int) pos.field_1350);
        class_2338 blockAt = new class_2338((int) pos.field_1352, (int) pos.field_1351, (int) pos.field_1350);

        boolean onWater = isWater(blockBelow);
        boolean onLava = isLava(blockBelow);
        boolean onWaterAt = isWater(blockAt);
        boolean onLavaAt = isLava(blockAt);

        if (!onWater && !onLava && !onWaterAt && !onLavaAt) return;

        if (mc.field_1724.method_18798().field_1351 < 0 && sink.isOn()) {
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0, mc.field_1724.method_18798().field_1350);
        }

        switch (mode.getValue()) {
            case "Solid" -> {
                if (mc.field_1724.method_5799() || mc.field_1724.method_5771()) return;
                if (mc.field_1724.method_18798().field_1351 < 0) {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0, mc.field_1724.method_18798().field_1350);
                }
                PacketUtil.spoofOnGround(true);
            }
            case "Bounce" -> {
                if (mc.field_1724.field_6235 > 0 && mc.field_1724.method_18798().field_1351 < 0) {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42, mc.field_1724.method_18798().field_1350);
                }
            }
            case "NCP" -> {
                if (mc.field_1724.method_5799() || mc.field_1724.method_5771()) return;
                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.1, mc.field_1724.method_18798().field_1350);
                PacketUtil.spoofOnGround(true);
                mc.field_1724.method_24830(true);
            }
        }
    }

    private boolean isWater(class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10382;
    }

    private boolean isLava(class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10164;
    }
}
