package com.hack.zero.module.player;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.NumberSetting;
import com.hack.zero.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1749;
import net.minecraft.class_1781;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

public class AirPlace extends Module {

    private final BooleanSetting render;
    private final NumberSetting range;
    private class_3965 renderHitResult;
    private class_3965 placeHitResult;

    public AirPlace() {
        super(
            "AirPlace",
            "Places blocks in mid-air where crosshair points without needing an adjacent supporting block.",
            Category.PLAYER,
            0
        );
        this.render = new BooleanSetting("Render", true);
        this.range  = new NumberSetting("Range", 5.0, 0.0, 6.0, 0.5);
        addSetting(this.render);
        addSetting(this.range);
    }

    @Override
    protected void onDisable() {
        renderHitResult = null;
        placeHitResult = null;
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_1799 mainHand = mc.field_1724.method_6047();
        class_1799 offHand = mc.field_1724.method_6079();
        if (!isPlaceable(mainHand) && !isPlaceable(offHand)) {
            renderHitResult = null;
            placeHitResult = null;
            return;
        }

        if (mc.field_1690.method_31044().method_31034()) {
            class_239 crosshair = mc.field_1765;
            if (crosshair != null && crosshair.method_17783() != class_239.class_240.field_1333) {
                renderHitResult = null;
                placeHitResult = null;
                return;
            }
        }

        double r = ((Number) range.getValue()).doubleValue();

        placeHitResult = raycastFromEntity(mc.field_1724, r);

        if (mc.field_1690.method_31044().method_31034()) {
            renderHitResult = placeHitResult;
        } else {
            class_1297 camera = mc.field_1719;
            if (camera != null) {
                renderHitResult = raycastFromEntity(camera, r);
            } else {
                renderHitResult = placeHitResult;
            }
        }

        if (mc.field_1690.field_1904.method_1434() && placeHitResult != null) {
            place();
        }
    }

    private class_3965 raycastFromEntity(class_1297 entity, double range) {
        class_243 eyePos = entity.method_33571();
        class_243 look = entity.method_5828(1.0f);
        class_243 end = eyePos.method_1019(look.method_1021(range));

        class_3959 ctx = new class_3959(
            eyePos,
            end,
            class_3959.class_3960.field_17559,
            class_3959.class_242.field_1348,
            entity
        );

        class_3965 result = mc.field_1687.method_17742(ctx);

        if (result.method_17783() != class_239.class_240.field_1333) {
            return result;
        }

        class_243 missPos = result.method_17784();
        int x = (int) Math.floor(missPos.field_1352);
        int y = (int) Math.floor(missPos.field_1351);
        int z = (int) Math.floor(missPos.field_1350);
        class_2338 pos = new class_2338(x, y, z);
        return class_3965.method_17778(missPos, class_2350.field_11036, pos);
    }

    private void place() {
        if (mc.field_1761 == null || mc.field_1724 == null || placeHitResult == null) return;

        class_2338 pos = placeHitResult.method_17777();
        if (pos == null) return;
        class_2680 state = mc.field_1687.method_8320(pos);

        if (!state.method_45474()) return;

        class_1799 mainHand = mc.field_1724.method_6047();
        class_1799 offHand = mc.field_1724.method_6079();
        class_1268 hand = isPlaceable(mainHand) ? class_1268.field_5808 : class_1268.field_5810;

        mc.field_1761.method_2896(mc.field_1724, hand, placeHitResult);
    }

    @Override
    public void onRender3D(class_4587 matrices, float tickDelta, WorldRenderContext context) {
        if (!render.isOn() || renderHitResult == null || context.consumers() == null) return;

        class_2338 pos = renderHitResult.method_17777();
        if (pos == null) return;
        class_243 cam = context.camera().method_19326();

        class_238 box = new class_238(
            pos.method_10263() - cam.field_1352,
            pos.method_10264() - cam.field_1351,
            pos.method_10260() - cam.field_1350,
            pos.method_10263() + 1.0 - cam.field_1352,
            pos.method_10264() + 1.0 - cam.field_1351,
            pos.method_10260() + 1.0 - cam.field_1350
        );

        RenderUtil.setupRenderState();
        try {
            class_4588 buffer = context.consumers().getBuffer(class_1921.method_23594());
            Matrix4f matrix = context.matrixStack().method_23760().method_23761();
            RenderUtil.drawBoxLines(buffer, matrix, box, 1.0f, 0.0f, 0.0f, 1.0f);
        } finally {
            RenderUtil.restoreRenderState();
        }
    }

    private boolean isPlaceable(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        return item instanceof class_1747
                || item instanceof class_1826
                || (item instanceof class_1749 && mc.field_1724 != null && mc.field_1724.method_5799())
                || item instanceof class_1781;
    }
}
