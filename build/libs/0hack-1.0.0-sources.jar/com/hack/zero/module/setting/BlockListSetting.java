package com.hack.zero.module.setting;

import java.util.Set;
import net.minecraft.class_2248;

public class BlockListSetting extends Setting<Set<class_2248>> {
    public BlockListSetting(String name, Set<class_2248> defaultValue) {
        super(name, defaultValue);
    }

    public boolean contains(class_2248 block) {
        return getValue().contains(block);
    }
}
