package com.hack.zero.module.combat;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.ModeSetting;
import com.hack.zero.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_2828;

public class KillAura extends Module {

    private final NumberSetting range = new NumberSetting("Range", 4.5, 1.0, 6.0, 0.1);
    private final ModeSetting mode = new ModeSetting("Mode", "Single", "Single", "Switch", "Multi");
    private final BooleanSetting targetPlayers = new BooleanSetting("Players", true);
    private final BooleanSetting targetMobs = new BooleanSetting("Mobs", true);
    private final BooleanSetting targetAnimals = new BooleanSetting("Animals", true);
    private final BooleanSetting throughWalls = new BooleanSetting("ThroughWalls", false);
    private final BooleanSetting forceCriticals = new BooleanSetting("ForceCriticals", true);

    private int switchIndex = 0;

    public KillAura() {
        super("KillAura", "Automatically attacks nearby targets", Category.COMBAT, 0);
        addSetting(range);
        addSetting(mode);
        addSetting(targetPlayers);
        addSetting(targetMobs);
        addSetting(targetAnimals);
        addSetting(throughWalls);
        addSetting(forceCriticals);
    }

    @Override
    protected void onEnable() {
        switchIndex = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        List<class_1309> targets = collectTargets();
        if (targets.isEmpty()) return;

        if ("Multi".equals(mode.getValue())) {
            for (class_1309 target : targets) {
                attack(target);
            }
        } else {
            class_1309 target = selectTarget(targets);
            if (target != null) {
                attack(target);
                if ("Switch".equals(mode.getValue()) && !targets.isEmpty()) {
                    switchIndex = (switchIndex + 1) % targets.size();
                }
            }
        }
    }

    private void attack(class_1309 target) {
        if (mc.field_1724.method_7261(0.0f) < 0.9f) return;

        if (forceCriticals.isOn() && mc.field_1724.method_5805() && mc.field_1724.method_24828()) {
            doPacketCrit();
        }

        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void doPacketCrit() {
        double x = mc.field_1724.method_23317();
        double y = mc.field_1724.method_23318();
        double z = mc.field_1724.method_23321();
        boolean hCol = mc.field_1724.field_5976;

        mc.method_1562().method_52787(
                new class_2828.class_2829(x, y + 0.0625, z, false, hCol));
        mc.method_1562().method_52787(
                new class_2828.class_2829(x, y, z, false, hCol));
        mc.method_1562().method_52787(
                new class_2828.class_2829(x, y + 1.1e-5, z, false, hCol));
        mc.method_1562().method_52787(
                new class_2828.class_2829(x, y, z, false, hCol));
    }

    private List<class_1309> collectTargets() {
        List<class_1309> result = new ArrayList<>();
        double rangeSq = range.getValue() * range.getValue();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) continue;
            if (living == mc.field_1724) continue;
            if (!living.method_5805()) continue;
            if (mc.field_1724.method_5858(living) > rangeSq) continue;
            if (!throughWalls.isOn() && !mc.field_1724.method_6057(living)) continue;
            if (!isAllowed(living)) continue;

            result.add(living);
        }

        result.sort(Comparator.comparingDouble(mc.field_1724::method_5858));
        return result;
    }

    private class_1309 selectTarget(List<class_1309> targets) {
        if (targets.isEmpty()) return null;
        if ("Switch".equals(mode.getValue())) {
            if (switchIndex >= targets.size()) switchIndex = 0;
            return targets.get(switchIndex);
        }
        return targets.getFirst();
    }

    private boolean isAllowed(class_1309 entity) {
        if (entity instanceof class_1657) return targetPlayers.isOn();
        if (entity instanceof class_1569) return targetMobs.isOn();
        if (entity instanceof class_1429 || entity instanceof class_1296) return targetAnimals.isOn();
        return false;
    }
}
