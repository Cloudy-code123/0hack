package com.hack.zero.module.combat;

import com.hack.zero.module.Category;
import com.hack.zero.module.Module;
import com.hack.zero.module.setting.BooleanSetting;
import com.hack.zero.module.setting.NumberSetting;
import net.minecraft.class_1713;
import net.minecraft.class_1802;

public class AutoTotem extends Module {
    private final BooleanSetting softSwitch = new BooleanSetting("SoftSwitch", false);
    private final NumberSetting healthThreshold = new NumberSetting("HealthThreshold", 8.0, 1.0, 20.0, 0.5);
    private long lastSwapTime = 0;

    public AutoTotem() {
        super("AutoTotem", "Equip totems automatically", Category.COMBAT, 0);
        addSetting(softSwitch);
        addSetting(healthThreshold);
        setExpandable(false);
    }

    @Override
    protected void onEnable() {
        lastSwapTime = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mc.field_1724.method_6079().method_7909() == class_1802.field_8288) return;

        if (mc.field_1724.method_6032() > healthThreshold.getValue()) return;

        long now = System.currentTimeMillis();
        if (now - lastSwapTime < 500) return;

        int totemSlot = findTotem();
        if (totemSlot == -1) return;

        lastSwapTime = now;
        int currentOffhand = 45;
        mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, totemSlot, 0, class_1713.field_7790, mc.field_1724);
        mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, currentOffhand, 0, class_1713.field_7790, mc.field_1724);

        if (!mc.field_1724.field_7512.method_34255().method_7960()) {
            if (softSwitch.isOn()) {
                int emptySlot = findEmptySlot();
                if (emptySlot != -1) {
                    mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, emptySlot, 0, class_1713.field_7790, mc.field_1724);
                }
            } else {
                mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, totemSlot, 0, class_1713.field_7790, mc.field_1724);
            }
        }
    }

    private int findTotem() {
        for (int i = 9; i < 45; i++) {
            if (mc.field_1724.field_7512.method_7611(i).method_7677().method_7909() == class_1802.field_8288) {
                return i;
            }
        }
        return -1;
    }

    private int findEmptySlot() {
        for (int i = 9; i < 45; i++) {
            if (mc.field_1724.field_7512.method_7611(i).method_7677().method_7960()) {
                return i;
            }
        }
        return -1;
    }
}
