package com.hack.zero.event.events;

import com.hack.zero.event.Event;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public class RenderEvent extends Event {
    private final class_4587 matrices;
    private final class_4597.class_4598 vertexConsumers;
    private final float tickDelta;

    public RenderEvent(class_4587 matrices, class_4597.class_4598 vertexConsumers, float tickDelta) {
        this.matrices = matrices;
        this.vertexConsumers = vertexConsumers;
        this.tickDelta = tickDelta;
    }

    public class_4587 getMatrices() {
        return matrices;
    }

    public class_4597.class_4598 getVertexConsumers() {
        return vertexConsumers;
    }

    public float getTickDelta() {
        return tickDelta;
    }
}
