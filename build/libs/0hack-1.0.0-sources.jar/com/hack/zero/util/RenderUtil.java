package com.hack.zero.util;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import org.joml.Matrix4f;

import java.util.OptionalDouble;
import net.minecraft.class_10799;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;

public class RenderUtil {

    // Modern 1.21.7 pipeline – NO depth test → sees through walls
    private static final RenderPipeline ESP_LINES_PIPELINE = RenderPipeline.builder(
            class_10799.field_56859
    )
    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
    .withDepthWrite(false)
    .withLocation("zerohack/esp_lines")
    .build();

    public static final class_1921 ESP_LINES = class_1921.method_24049(
            "zerohack_esp_lines",
            1536,
            false,
            true,
            ESP_LINES_PIPELINE,
            class_1921.class_4688.method_23598()
                    .method_23609(new class_4668.class_4677(OptionalDouble.of(2.5)))
                    .method_23617(false)
    );

    public static class_1921 getEspLines() {
        return ESP_LINES;
    }

    public static void setupRenderState() {
        GlStateManager._disableDepthTest();
        GlStateManager._depthMask(false);
        GlStateManager._enableBlend();
        GlStateManager._disableCull();
    }

    public static void restoreRenderState() {
        GlStateManager._enableDepthTest();
        GlStateManager._depthMask(true);
        GlStateManager._enableCull();
        GlStateManager._disableBlend();
    }

    public static void drawBoxLines(class_4588 buffer, Matrix4f matrix, class_238 box,
                                     float r, float g, float b, float a) {
        float x1 = (float) box.field_1323, y1 = (float) box.field_1322, z1 = (float) box.field_1321;
        float x2 = (float) box.field_1320, y2 = (float) box.field_1325, z2 = (float) box.field_1324;

        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a).method_22914(1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a).method_22914(1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a).method_22914(0, 0, 1).method_60803(15728880);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a).method_22914(0, 0, 1).method_60803(15728880);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a).method_22914(-1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a).method_22914(-1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a).method_22914(0, 0, -1).method_60803(15728880);
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a).method_22914(0, 0, -1).method_60803(15728880);

        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a).method_22914(1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a).method_22914(1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a).method_22914(0, 0, 1).method_60803(15728880);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a).method_22914(0, 0, 1).method_60803(15728880);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a).method_22914(-1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a).method_22914(-1, 0, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a).method_22914(0, 0, -1).method_60803(15728880);
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a).method_22914(0, 0, -1).method_60803(15728880);

        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
    }

    public static void drawLine(class_4587 matrices, class_4597 consumers,
                                 class_243 from, class_243 to, int color) {
        float a = (float) (color >> 24 & 0xFF) / 255.0f;
        float r = (float) (color >> 16 & 0xFF) / 255.0f;
        float g = (float) (color >> 8 & 0xFF) / 255.0f;
        float b = (float) (color & 0xFF) / 255.0f;
        if (a == 0.0f) a = 1.0f;

        Matrix4f matrix = matrices.method_23760().method_23761();
        class_4588 buffer = consumers.getBuffer(class_1921.method_23594());
        buffer.method_22918(matrix, (float) from.field_1352, (float) from.field_1351, (float) from.field_1350)
              .method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
        buffer.method_22918(matrix, (float) to.field_1352, (float) to.field_1351, (float) to.field_1350)
              .method_22915(r, g, b, a).method_22914(0, 1, 0).method_60803(15728880);
    }
}
