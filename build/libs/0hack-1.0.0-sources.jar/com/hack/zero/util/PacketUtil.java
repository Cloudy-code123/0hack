package com.hack.zero.util;

import net.minecraft.class_2828;
import net.minecraft.class_310;

public class PacketUtil {
    private static final class_310 mc = class_310.method_1551();

    public static void sendPacket(net.minecraft.class_2596<?> packet) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(packet);
        }
    }

    public static void sendPosition(double x, double y, double z, boolean onGround) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(new class_2828.class_2829(x, y, z, onGround, false));
        }
    }

    public static void sendRotation(float yaw, float pitch, boolean onGround) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(new class_2828.class_2831(yaw, pitch, onGround, false));
        }
    }

    public static void sendPositionAndRotation(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(new class_2828.class_2830(x, y, z, yaw, pitch, onGround, false));
        }
    }

    public static void spoofOnGround(boolean onGround) {
        if (mc.field_1724 != null && mc.method_1562() != null) {
            mc.method_1562().method_52787(new class_2828.class_5911(onGround, false));
        }
    }

    public static void jitterRotation(float yawOffset, float pitchOffset) {
        if (mc.field_1724 == null) return;
        java.util.Random random = new java.util.Random();
        float yaw = mc.field_1724.method_36454() + (random.nextFloat() - 0.5f) * yawOffset;
        float pitch = mc.field_1724.method_36455() + (random.nextFloat() - 0.5f) * pitchOffset;
        pitch = Math.max(-90, Math.min(90, pitch));
        sendRotation(yaw, pitch, mc.field_1724.method_24828());
    }
}
