package com.hack.zero.util;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationUtil {
    private static final class_310 mc = class_310.method_1551();

    public static float[] getRotations(class_1297 entity) {
        if (mc.field_1724 == null) return new float[]{0, 0};
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 targetPos = entity instanceof class_1309 living
                ? living.method_19538().method_1031(0, living.method_5751() * 0.85, 0)
                : entity.method_19538().method_1031(0, entity.method_17682() * 0.5, 0);

        double dx = targetPos.field_1352 - eyePos.field_1352;
        double dy = targetPos.field_1351 - eyePos.field_1351;
        double dz = targetPos.field_1350 - eyePos.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        return new float[]{
                mc.field_1724.method_36454() + class_3532.method_15393(yaw - mc.field_1724.method_36454()),
                class_3532.method_15363(pitch, -90.0f, 90.0f)
        };
    }

    public static float[] getRotationTo(double x, double y, double z) {
        if (mc.field_1724 == null) return new float[]{0, 0};
        class_243 eyePos = mc.field_1724.method_33571();
        double dx = x - eyePos.field_1352;
        double dy = y - eyePos.field_1351;
        double dz = z - eyePos.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        return new float[]{
                mc.field_1724.method_36454() + class_3532.method_15393(yaw - mc.field_1724.method_36454()),
                class_3532.method_15363(pitch, -90.0f, 90.0f)
        };
    }

    public static float[] lerpRotation(float[] current, float[] target, float speed) {
        float yawDiff = class_3532.method_15393(target[0] - current[0]);
        float pitchDiff = target[1] - current[1];
        return new float[]{
                current[0] + yawDiff * speed,
                class_3532.method_15363(current[1] + pitchDiff * speed, -90.0f, 90.0f)
        };
    }

    public static float getAngleDiff(float a, float b) {
        return class_3532.method_15393(a - b);
    }

    public static boolean isLookingAt(class_1297 entity, float fov) {
        if (mc.field_1724 == null) return false;
        float[] rot = getRotations(entity);
        float yawDiff = Math.abs(getAngleDiff(rot[0], mc.field_1724.method_36454()));
        float pitchDiff = Math.abs(rot[1] - mc.field_1724.method_36455());
        return yawDiff < fov / 2 && pitchDiff < fov / 2;
    }
}
