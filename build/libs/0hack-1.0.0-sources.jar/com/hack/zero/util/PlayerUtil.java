package com.hack.zero.util;

import net.minecraft.class_243;
import net.minecraft.class_310;

public class PlayerUtil {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isPlayerNull() {
        return mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null;
    }

    public static boolean isMoving() {
        return mc.field_1724 != null && (getInputForward() != 0 || getInputSideways() != 0);
    }

    public static float getInputForward() {
        if (mc.field_1724 == null) return 0;
        float forward = 0;
        if (mc.field_1690.field_1894.method_1434()) forward += 1;
        if (mc.field_1690.field_1881.method_1434()) forward -= 1;
        return forward;
    }

    public static float getInputSideways() {
        if (mc.field_1724 == null) return 0;
        float sideways = 0;
        if (mc.field_1690.field_1913.method_1434()) sideways += 1;
        if (mc.field_1690.field_1849.method_1434()) sideways -= 1;
        return sideways;
    }

    public static double getSpeed() {
        if (mc.field_1724 == null) return 0;
        class_243 vel = mc.field_1724.method_18798();
        return Math.sqrt(vel.field_1352 * vel.field_1352 + vel.field_1350 * vel.field_1350);
    }

    public static class_243 getPlayerPos() {
        if (mc.field_1724 == null) return class_243.field_1353;
        return mc.field_1724.method_19538();
    }

    public static boolean isOnLiquid() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;
        class_243 pos = mc.field_1724.method_19538();
        return mc.field_1687.method_8320(new net.minecraft.class_2338((int) pos.field_1352, (int) (pos.field_1351 - 0.1), (int) pos.field_1350)).method_26227().method_15771();
    }

    public static boolean isOnWater() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;
        class_243 pos = mc.field_1724.method_19538();
        return mc.field_1687.method_8320(new net.minecraft.class_2338((int) pos.field_1352, (int) (pos.field_1351 - 0.1), (int) pos.field_1350)).method_26227().method_39360(net.minecraft.class_3612.field_15910);
    }

    public static boolean isOnLava() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;
        class_243 pos = mc.field_1724.method_19538();
        return mc.field_1687.method_8320(new net.minecraft.class_2338((int) pos.field_1352, (int) (pos.field_1351 - 0.1), (int) pos.field_1350)).method_26227().method_39360(net.minecraft.class_3612.field_15908);
    }

    public static boolean isGliding() {
        return mc.field_1724 != null && mc.field_1724.method_6128();
    }
}
