package com.hack.zero.util;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;

public final class BlockUtils {
    private static final ThreadLocal<class_2338.class_2339> EXPOSED_POS = ThreadLocal.withInitial(class_2338.class_2339::new);

    private BlockUtils() {
    }

    public static boolean isExposed(class_2338 blockPos) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return false;

        for (class_2350 direction : class_2350.values()) {
            if (!mc.field_1687.method_8320(EXPOSED_POS.get().method_25505(blockPos, direction)).method_26225()) return true;
        }

        return false;
    }
}
